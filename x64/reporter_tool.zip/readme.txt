1. 快速启动
1.1 双击test_dll.exe 生成result.txt文件；
1.2 python test.py 生成报告result.xlsx

2. 注意
test/images  是测试图像固定路径
models 是模型固定路径

3. 报告场景解释

common 正常图像
dark 过暗
overexposure 过曝
overexposure_dark 过暗+过曝
tilted 倾斜
other 未使用以上字段的场景图像